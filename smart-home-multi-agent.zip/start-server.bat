@echo off
echo ========================================
echo 智能家居同步服务器
echo ========================================
echo.
echo 正在启动服务器...
echo.

node sync-server.js

pause
